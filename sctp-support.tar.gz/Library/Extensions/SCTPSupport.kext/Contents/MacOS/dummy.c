int dummy(voivoidd)
{
	return 0;
}
