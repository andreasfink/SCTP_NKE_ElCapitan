
int a;


